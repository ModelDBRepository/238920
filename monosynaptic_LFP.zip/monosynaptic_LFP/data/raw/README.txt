Various files with data shared by Harvey Swadlow and convertion scripts used
to produce the cPickle files in the above folder. 